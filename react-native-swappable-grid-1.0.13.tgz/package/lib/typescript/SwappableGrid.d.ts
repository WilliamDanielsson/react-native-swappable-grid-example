import React, { ReactNode } from "react";
import { StyleProp, ViewStyle } from "react-native";
/**
 * Props for the SwappableGrid component
 */
type SwappableGridProps = {
    /** The child components to render in the grid. Each child should have a unique key. */
    children: ReactNode;
    /** Width of each grid item in pixels. Optional if items report their own dimensions via onLayout. */
    itemWidth?: number;
    /** Height of each grid item in pixels. Optional if items report their own dimensions via onLayout. */
    itemHeight?: number;
    /** Gap between grid items in pixels. Defaults to 8. */
    gap?: number;
    /** Padding around the container in pixels. Defaults to 8. */
    containerPadding?: number;
    /** Duration in milliseconds to hold before drag starts. Defaults to 300. */
    holdToDragMs?: number;
    /** Number of columns in the grid. If not provided, will be calculated automatically based on container width. */
    numColumns?: number;
    /** Wiggle animation configuration when items are in drag mode or delete mode */
    wiggle?: {
        /** Duration of one wiggle cycle in milliseconds */
        duration: number;
        /** Rotation degrees for the wiggle animation */
        degrees: number;
    };
    /** Wiggle animation configuration specifically for delete mode. If not provided, uses 2x degrees and 0.7x duration of wiggle prop. */
    wiggleDeleteMode?: {
        /** Duration of one wiggle cycle in milliseconds */
        duration: number;
        /** Rotation degrees for the wiggle animation */
        degrees: number;
    };
    /** Duration in milliseconds to hold an item still before entering delete mode. Defaults to 1000. */
    holdStillToDeleteMs?: number;
    /** Enable haptic feedback (vibration) when entering delete mode. Defaults to false. */
    hapticFeedback?: boolean;
    /** Callback fired when drag ends, providing the ordered array of child nodes */
    onDragEnd?: (ordered: ChildNode[]) => void;
    /** Callback fired when the order changes, providing an array of keys in the new order */
    onOrderChange?: (keys: string[]) => void;
    /** Callback fired when an item is deleted, providing the key of the deleted item */
    onDelete?: (key: string) => void;
    /** Factor by which the dragged item scales up. Defaults to 1.06. */
    dragSizeIncreaseFactor?: number;
    /** Speed of auto-scrolling when dragging near edges. Defaults to 10. */
    scrollSpeed?: number;
    /** Distance from edge in pixels that triggers auto-scroll. Defaults to 100. */
    scrollThreshold?: number;
    /** Custom style for the ScrollView container */
    style?: StyleProp<ViewStyle>;
    /** Component to render after all grid items (e.g., an "Add" button) */
    trailingComponent?: ReactNode;
    /** Component to render as a delete target (shown when dragging). If provided, disables hold-to-delete feature. */
    deleteComponent?: ReactNode;
    /** Custom style for the delete component. If provided, allows custom positioning. */
    deleteComponentStyle?: StyleProp<ViewStyle>;
    /** If true, reverses the order of items (right-to-left, bottom-to-top). Defaults to false. */
    reverse?: boolean;
};
/**
 * Ref methods for SwappableGrid component
 */
export interface SwappableGridRef {
    /** Cancels the delete mode if any item is currently in delete mode */
    cancelDeleteMode: () => void;
}
/**
 * SwappableGrid - A React Native component for creating a draggable, swappable grid layout.
 *
 * Features:
 * - Drag and drop to reorder items
 * - Long press to enter drag mode
 * - Auto-scroll when dragging near edges
 * - Optional wiggle animation during drag mode
 * - Optional delete functionality with hold-to-delete or delete component
 * - Support for trailing components (e.g., "Add" button)
 * - Automatic column calculation based on container width
 *
 * @example
 * ```tsx
 * <SwappableGrid
 *   itemWidth={100}
 *   itemHeight={100}
 *   numColumns={3}
 *   onOrderChange={(keys) => console.log('New order:', keys)}
 * >
 *   {items.map(item => (
 *     <View key={item.id}>{item.content}</View>
 *   ))}
 * </SwappableGrid>
 * ```
 */
declare const SwappableGrid: React.ForwardRefExoticComponent<SwappableGridProps & React.RefAttributes<SwappableGridRef>>;
export default SwappableGrid;
