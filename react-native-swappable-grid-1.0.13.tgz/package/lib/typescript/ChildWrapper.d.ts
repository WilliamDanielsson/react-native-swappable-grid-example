import React from "react";
import { SharedValue } from "react-native-reanimated";
type Props = {
    position: {
        x: SharedValue<number>;
        y: SharedValue<number>;
        active: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    };
    defaultWidth?: number;
    defaultHeight?: number;
    onDimensionsChange?: (width: number, height: number) => void;
    dragMode: SharedValue<boolean>;
    anyItemInDeleteMode: SharedValue<boolean>;
    isPressingDeleteItem: SharedValue<boolean>;
    children: React.ReactNode;
    wiggle?: {
        duration: number;
        degrees: number;
    };
    wiggleDeleteMode?: {
        duration: number;
        degrees: number;
    };
    holdStillToDeleteMs?: number;
    dragSizeIncreaseFactor: number;
    onDelete?: () => void;
    disableHoldToDelete?: boolean;
    hapticFeedback?: boolean;
};
export default function ChildWrapper({ position, defaultWidth, defaultHeight, onDimensionsChange, dragMode, anyItemInDeleteMode, isPressingDeleteItem, children, wiggle, wiggleDeleteMode, holdStillToDeleteMs, dragSizeIncreaseFactor, onDelete, disableHoldToDelete, hapticFeedback, }: Props): React.JSX.Element;
export {};
