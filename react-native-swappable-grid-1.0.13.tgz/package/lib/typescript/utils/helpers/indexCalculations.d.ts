import { SharedValue } from "react-native-reanimated";
interface IndexToXYProps {
    index: number;
    itemHeight: number;
    itemWidth: number;
    dynamicNumColumns: SharedValue<number>;
    containerPadding: number;
    gap: number;
}
interface DynamicIndexToXYProps {
    index: number;
    order: SharedValue<string[]>;
    positions: Record<string, {
        x: SharedValue<number>;
        y: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    }>;
    dynamicNumColumns: SharedValue<number>;
    containerPadding: number;
    gap: number;
    defaultWidth: number;
    defaultHeight: number;
}
export declare const indexToXY: ({ index, itemHeight, itemWidth, dynamicNumColumns, containerPadding, gap, }: IndexToXYProps) => {
    x: number;
    y: number;
};
interface FlowLayoutProps {
    index: number;
    order: SharedValue<string[]>;
    positions: Record<string, {
        x: SharedValue<number>;
        y: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    }>;
    containerWidth: SharedValue<number>;
    containerPadding: number;
    gap: number;
    defaultWidth: number;
    defaultHeight: number;
    activeKey?: SharedValue<string | null>;
}
export declare const indexToXYFlow: ({ index, order, positions, containerWidth, containerPadding, gap, defaultWidth, defaultHeight, activeKey, }: FlowLayoutProps) => {
    x: number;
    y: number;
};
export declare const indexToXYDynamic: ({ index, order, positions, dynamicNumColumns, containerPadding, gap, defaultWidth, defaultHeight, }: DynamicIndexToXYProps) => {
    x: number;
    y: number;
};
interface XYToIndexProps {
    order: SharedValue<string[]>;
    x: number;
    y: number;
    itemHeight: number;
    itemWidth: number;
    dynamicNumColumns: SharedValue<number>;
    containerPadding: number;
    gap: number;
}
export declare const xyToIndex: ({ order, x, y, itemHeight, itemWidth, dynamicNumColumns, gap, containerPadding, }: XYToIndexProps) => number;
interface DynamicXYToIndexProps {
    order: SharedValue<string[]>;
    x: number;
    y: number;
    positions: Record<string, {
        x: SharedValue<number>;
        y: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    }>;
    dynamicNumColumns: SharedValue<number>;
    containerPadding: number;
    gap: number;
    defaultWidth: number;
    defaultHeight: number;
    activeKey?: SharedValue<string | null>;
}
export declare const xyToIndexDynamic: ({ order, x, y, positions, dynamicNumColumns, containerPadding, gap, defaultWidth, defaultHeight, activeKey, }: DynamicXYToIndexProps) => number;
export declare const xyToIndexFlow: ({ order, x, y, positions, containerWidth, containerPadding, gap, defaultWidth, defaultHeight, activeKey, }: {
    order: SharedValue<string[]>;
    x: number;
    y: number;
    positions: Record<string, {
        x: SharedValue<number>;
        y: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    }>;
    containerWidth: SharedValue<number>;
    containerPadding: number;
    gap: number;
    defaultWidth: number;
    defaultHeight: number;
    activeKey?: SharedValue<string | null>;
}) => number;
export declare const toIndex1ColFromLiveMidlines: (order: SharedValue<string[]>, positions: Record<string, {
    y: SharedValue<number>;
    height?: SharedValue<number>;
}>, activeKey: SharedValue<string | null>, itemHeight: number, centerY: number, reverse: boolean) => number;
export {};
