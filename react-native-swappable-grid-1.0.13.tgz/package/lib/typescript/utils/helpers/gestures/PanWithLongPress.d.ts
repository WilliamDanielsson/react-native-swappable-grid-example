import { SharedValue, AnimatedRef } from "react-native-reanimated";
interface PanProps {
    order: SharedValue<string[]>;
    dynamicNumColumns: SharedValue<number>;
    activeKey: SharedValue<string | null>;
    offsetX: SharedValue<number>;
    offsetY: SharedValue<number>;
    startX: SharedValue<number>;
    startY: SharedValue<number>;
    dragMode: SharedValue<boolean>;
    positions: any;
    itemsByKey: any;
    itemWidth: number;
    itemHeight: number;
    containerPadding: number;
    gap: number;
    setOrderState: React.Dispatch<React.SetStateAction<string[]>>;
    onDragEnd?: (ordered: ChildNode[]) => void;
    onOrderChange?: (keys: string[]) => void;
    scrollSpeed: number;
    scrollThreshold: number;
    scrollViewRef: AnimatedRef<any>;
    scrollOffset: SharedValue<number>;
    viewportH: SharedValue<number>;
    holdToDragMs: number;
    contentH: SharedValue<number>;
    contentW: SharedValue<number>;
    numColumns?: number;
    reverse?: boolean;
    deleteComponentPosition?: SharedValue<{
        x: number;
        y: number;
        width: number;
        height: number;
    } | null>;
    deleteItem?: (key: string) => void;
    contentPaddingBottom?: number;
}
export declare const PanWithLongPress: (props: PanProps & {
    holdToDragMs: number;
}) => import("react-native-gesture-handler/lib/typescript/handlers/gestures/panGesture").PanGesture;
export {};
