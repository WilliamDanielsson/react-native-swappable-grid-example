export default function computeMinHeight(count: number, numColumns: number, tileH: number, pad: number): number;
