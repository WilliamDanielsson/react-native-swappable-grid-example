import { ReactNode } from "react";
import { LayoutChangeEvent } from "react-native";
import { AnimatedRef, SharedValue } from "react-native-reanimated";
interface useGridLayoutProps {
    reverse?: boolean;
    children: ReactNode;
    itemWidth?: number;
    itemHeight?: number;
    gap: number;
    containerPadding: number;
    holdToDragMs: number;
    numColumns?: number;
    onDragEnd?: (ordered: ChildNode[]) => void;
    onOrderChange?: (keys: string[]) => void;
    onDelete?: (key: string) => void;
    scrollViewRef: AnimatedRef<any>;
    scrollSpeed: number;
    scrollThreshold: number;
    contentPaddingBottom?: number;
}
export declare function useGridLayout({ reverse, children, itemWidth, // Default fallback
itemHeight, // Default fallback
gap, containerPadding, holdToDragMs, numColumns, onDragEnd, onOrderChange, onDelete, scrollViewRef, scrollSpeed, scrollThreshold, contentPaddingBottom, }: useGridLayoutProps): {
    itemsByKey: Record<string, ReactNode>;
    orderState: string[];
    dragMode: SharedValue<boolean>;
    anyItemInDeleteMode: SharedValue<boolean>;
    isPressingDeleteItem: SharedValue<boolean>;
    composed: import("react-native-gesture-handler/lib/typescript/handlers/gestures/gestureComposition").SimultaneousGesture;
    dynamicNumColumns: SharedValue<number>;
    onLayoutContent: (e: LayoutChangeEvent) => void;
    onLayoutScrollView: (e: LayoutChangeEvent) => void;
    positions: Record<string, {
        x: SharedValue<number>;
        y: SharedValue<number>;
        active: SharedValue<number>;
        width: SharedValue<number>;
        height: SharedValue<number>;
    }>;
    onScroll: import("react-native-reanimated").ScrollHandlerProcessed<Record<string, unknown>>;
    childArray: import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>[];
    order: SharedValue<string[]>;
    deleteItem: (key: string) => void;
    deleteComponentPosition: SharedValue<{
        x: number;
        y: number;
        width: number;
        height: number;
    }>;
    updateItemDimensions: (key: string, width: number, height: number) => void;
};
export {};
